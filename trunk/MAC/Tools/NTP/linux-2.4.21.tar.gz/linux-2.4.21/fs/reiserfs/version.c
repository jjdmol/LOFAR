/*
 * Copyright 2000-2002 by Hans Reiser, licensing governed by reiserfs/README
 */

char *reiserfs_get_version_string(void) {
  return "ReiserFS version 3.6.25" ;
}
