global list;
Signal_modulation=[];
count_file=1;
count_signal=0;
clear Modulated_signal;
clear feature_mod;
DSP_1inst=[];
resu_poly=[];
OutputSignal=[];
mat1=[];
set(List_modulation,'String',list);
subplot(HPerioMod)
cla