function hello(nbre);

switch nbre 
    
case 1
    disp('sin');
    %Ampl_sig*sin(2*pi*Freq*t)
case 2
    disp('Cosin');
case 3
    disp('Sawtooth')
case 4
    disp('rectpulse')
case 5
    disp('Gaussian pulse')
case 6
    disp('square')
end                        