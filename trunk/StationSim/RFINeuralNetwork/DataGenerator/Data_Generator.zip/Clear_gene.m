global res;
global ans;
global list;

clear res;
clear s;
clear ans;
list={};
indice=0;
count_sig=0;
clear features;
set(listbox_signal,'String',list);
subplot(HPerioFilFig);
cla
subplot(HPerioFig); 
cla
subplot(HPerioFilter);
cla
subplot(HPerioFigresu); 
cla
subplot(HPerioFigPlot);
cla