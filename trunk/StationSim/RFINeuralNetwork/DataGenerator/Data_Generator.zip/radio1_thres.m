if get(RadioThres1,'Value')==1
set(RadioThres2,'Value',0)
else set(RadioThres2,'Value',1)
end
end
