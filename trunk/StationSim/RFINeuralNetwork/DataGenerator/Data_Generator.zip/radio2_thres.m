if get(RadioThres2,'Value')==1
set(RadioThres1,'Value',0)
else set(RadioThres1,'Value',1)
end
