clear res;
clear s;
clear ans;
clear list;
indice=0;
count_sig=0;
features;