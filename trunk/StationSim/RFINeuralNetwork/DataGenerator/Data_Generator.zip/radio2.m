if get(Checkbox2,'Value')==1
set(Checkbox1,'Value',0)
else set(Checkbox1,'Value',1)
end