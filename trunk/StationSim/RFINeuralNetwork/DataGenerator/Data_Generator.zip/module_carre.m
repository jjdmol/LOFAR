function [module_car]=module_carre(a);

module_car=power(real(a),2)+power(imag(a),2);