if get(Checkbox1,'Value')==1
set(Checkbox2,'Value',0)
else set(Checkbox2,'Value',1)
end
